﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace RazorPages.Models
{
    public class User
    {

            [Key]
            public int Id { get; set; }

            [Required]
            public string Name { get; set; }

            [Required]
            public string Surname { get; set; }

            [Required]
            [DataType(DataType.EmailAddress)]
            public string Email { get; set; }

            [Required]
            [DataType(DataType.Password)]
            public string Password { get; set; }

            // 1 to many relationship with user
            public List<Image> Images { get; set; }

            // 1 to many relationship with user
            public List<Comment> Comments { get; set; }
            public List<FollowedUser> FollowedUsers { get; set; }
            public List<FollowRequest> FollowedRequests { get; set; }
        

    }
}
