﻿
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace RazorPages.Models
{
    public class Image
    {
        [Key]
        public int Id { get; set; }
        public string Imagepath { get; set; }

        [DataType(DataType.Date)]
        public DateTime CreateTime { get; set; } = DateTime.Now;


        /*      To be foreign key of "Id" , add the "User" type in front of it.    */
        public int UserId { get; set; }
        public User User { get; set; }
        public List<Comment> Comments { get; set; }

    }
}
