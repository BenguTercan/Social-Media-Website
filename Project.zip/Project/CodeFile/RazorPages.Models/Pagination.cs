﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RazorPages.Models
{
    public class Pagination
    {
        // Fotoğrafların toplam sayısı
        public int totalImages { get; set; }
        public int totalImage2 { get; set; }

        // Her sayfada gösterilecek foroğraf sayısı
        public int imagesPerPage { get; set; }

        // Güncel sayfa
        public int currentPage { get; set; }


    }
}
