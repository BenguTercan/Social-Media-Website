using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RazorPages.Models;
using RazorPages.Services;

namespace deneme2_04._08_.Pages.Register
{
    public class IndexModel : PageModel
    {
        private AppDbContext db;

        [BindProperty]
        public User newUser { get; set; }

        public string WarningMessage { get; set; }

        public IndexModel(AppDbContext _db)
        {
            db = _db;
        }


        public IActionResult OnGet()
        {
            newUser = new User();
            return Page();
        }

        public IActionResult OnPost()
        {

            var myUser = register(newUser.Email);

            if (!ModelState.IsValid)
            {
                return Page();

            }

            // user does not exist. Add him/her to database
            else if (myUser == null)
            {
                newUser.Password = BCrypt.Net.BCrypt.HashPassword(newUser.Password);
                db.Users.Add(newUser);
                db.SaveChanges();
                return RedirectToPage("/Login/Index");
            }

            else
            {
                WarningMessage = " The User exists. Please register with different email ! ";
                return Page();
            }

        }

        private User register(string email)
        {
            var findUser = db.Users.Where(x => x.Email == email).SingleOrDefault();

            if (findUser == null)
                return null;
            else
                return findUser;
        }

    }

}
