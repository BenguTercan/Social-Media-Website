﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RazorPages.Models;
using RazorPages.Services;

namespace deneme2_04._08_.Pages.Login
{
    public class IndexModel : PageModel
    {
        private AppDbContext db;

        [BindProperty]
        public User existingUser { get; set; }

        public string WarningMessage { get; set; }

        public IndexModel(AppDbContext _db)
        {
            db = _db;
        }

        public void OnGet()
        {
            existingUser = new User();
        }

        public async Task<IActionResult> OnPost()
        {
            var exist = login(existingUser.Email, existingUser.Password);

            // if user cannot logged in
            if (exist == null)
            {
                WarningMessage = " Your mail address or password is wrong. Please try again ! ";
                return Page();
            }

            else
            {
                string Fullname = exist.Name + " " + exist.Surname ;
                HttpContext.Session.SetString("userFullname", Fullname );
                
                // get entered user informations into a claim list
                var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, exist.Email),
                    new Claim("FullName", Fullname),
                    new Claim(ClaimTypes.NameIdentifier,exist.Id.ToString()),
                };

                // add information of claims variable to Cookie Authentication Scheme
                var claimsIdentity = new ClaimsIdentity(
                    claims, CookieAuthenticationDefaults.AuthenticationScheme);

                // specify Authentication Properties
                var authProperties = new AuthenticationProperties
                {
                    AllowRefresh = true,
                    // Refreshing the authentication session should be allowed.

                    ExpiresUtc = DateTimeOffset.UtcNow.AddMinutes(30),
                    // The time at which the authentication ticket expires. A 
                    // value set here overrides the ExpireTimeSpan option of 
                    // CookieAuthenticationOptions set with AddCookie.

                    IsPersistent = true,
                    // Whether the authentication session is persisted across 
                    // multiple requests. When used with cookies, controls
                    // whether the cookie's lifetime is absolute (matching the
                    // lifetime of the authentication ticket) or session-based.
                };

                await HttpContext.SignInAsync(
                    CookieAuthenticationDefaults.AuthenticationScheme,
                    new ClaimsPrincipal(claimsIdentity),
                    authProperties);

                return Redirect("~/Login/HomePage");
            }

        }


        private User login(string email, string password)
        {
            var existingUser = db.Users.SingleOrDefault(x => x.Email == email);

            if(existingUser != null)
            {
                if (BCrypt.Net.BCrypt.Verify(password, existingUser.Password))
                    return existingUser;
            }

            return null;
        }

    }
}
