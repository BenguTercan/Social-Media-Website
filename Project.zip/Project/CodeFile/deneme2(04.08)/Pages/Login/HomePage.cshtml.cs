﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RazorPages.Models;
using RazorPages.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using System.IO;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;


namespace deneme2_04._08_.Pages.Login
{
    public class HomePageModel : PageModel
    {

        private AppDbContext db;

        // to hold page number
        static int staticP = 1 ;

        [BindProperty]
        public User currentUser { get; set; }

        [BindProperty]
        public IFormFile myFile { get; set; }

        [BindProperty]
        public List<Image> AllImages { get; set; } = new();

        [BindProperty]
        public IEnumerable<Comment> AllComments { get; set; }

        [BindProperty]
        public Pagination PagingInfo { get; set; }

        [BindProperty]
        public List<string> newText { get; set; }


        public HomePageModel(AppDbContext _db)
        {
            db = _db;
        }


        private void InitiliazeProperties(int id, AppDbContext db)
        {
            /*  To retrieve user's related images we have to use the Include Method. 
                Then join the user table and image table with User.Id and Image.UserId   */

            currentUser = db.Users.Include(x => x.FollowedUsers).Include(x => x.Images).Include(x => x.Comments).FirstOrDefault(x => x.Id == id);

            AllComments = db.Comments.Include(x => x.User).Include(x => x.Image).ToList();


            // if current user follows at least 1 person, show the followed user's and current user's posts on Homepage.
            if (currentUser.FollowedUsers.Count > 0)
            {
                // find and store all Ids of followed users
                var followeeIDs = currentUser.FollowedUsers.ToList().Select(x => x.FollowedId);

                // get current user's all images to HomePage
                AllImages.AddRange(db.Images.Where(x => x.UserId == currentUser.Id).Include(x=>x.User).Include(x=>x.Comments).AsEnumerable());
                if (followeeIDs != null)
                {
                    foreach (var followeeID in followeeIDs)
                    {
                        // get followed user's all images
                        var myImages = db.Images.Where(x => x.UserId == followeeID).Include(x => x.User).Include(x => x.Comments)
                            .AsEnumerable();
                        // instead of 1 image per followed user, get all images of followed user
                        AllImages.AddRange(myImages);
                    }
                }
            }

            // if there is no followed user, just get the current user's images to Homepage
            else
                AllImages = db.Images
                    .Where(x => x.UserId == currentUser.Id)
                    .Include(x => x.User)
                    .Include(x => x.Comments).ToList();

        }

        // pagination
        public IActionResult OnGet(int p = 1, int s = 6)
        {
            staticP = p;
            // get Id of currentUser from "claims" variable of Cookie Authentication Scheme to "HomePage" Razor Page
            var strUserId = User.Claims.FirstOrDefault(x => x.Type == ClaimTypes.NameIdentifier)?.Value;
            // convert coming string userId to Integer
            int userId = int.Parse(strUserId);
            InitiliazeProperties(userId, db);


            PagingInfo = new Pagination()
            {
                currentPage = p,
                imagesPerPage = s,
                totalImages = AllImages.Count(),
            };

            // get images in groups of 6 per page
            AllImages = AllImages.OrderByDescending(x => x.CreateTime).Skip((p - 1) * 6)
                    .Take(6)
                    .ToList();
            return Page();
        }


        // delete images
        public IActionResult OnGetDeleteimage(int id, string path)
        {

            var strUserId = User.Claims.FirstOrDefault(x => x.Type == ClaimTypes.NameIdentifier)?.Value;
            int userId = int.Parse(strUserId);
            InitiliazeProperties(userId, db);


            // delete image from database using its "id"
            var deletedImage = db.Images.Find(id);
            db.Remove(deletedImage);
            db.SaveChanges();


            // delete image from wwwroot/images folder using its "path"
            path = Path.Combine("wwwroot", path);
            FileInfo fi = new FileInfo(path);
            if (fi != null)
            {
                System.IO.File.Delete(path);
                fi.Delete();
            }

            return RedirectToPage(new { p = staticP, s = 6 });
        }


        // delete comments
        public IActionResult OnGetDeletecomment(int id)
        {
            var strUserId = User.Claims.FirstOrDefault(x => x.Type == ClaimTypes.NameIdentifier)?.Value;
            int userId = int.Parse(strUserId);
            InitiliazeProperties(userId, db);


            // delete comment from database using its "id"
            var deletedComment = db.Comments.Find(id);
            db.Remove(deletedComment);
            db.SaveChanges();

            return RedirectToPage(new { p = staticP, s = 6 });
        }


        // share images
        public IActionResult OnPost()
        {
            string uniqueFileName = null;

            var strUserId = User.Claims.FirstOrDefault(x => x.Type == ClaimTypes.NameIdentifier)?.Value;
            int userId = int.Parse(strUserId);
            InitiliazeProperties(userId, db);


            /*  wwwroot/images'e yeni yüklediğimiz resmi kopyalıyoruz(ekliyoruz). --> //wwwroot//images//kalp.jpg
                This method composes individual strings into a single string that represents a file path.*/
            if (myFile != null)
            {
                string upfolder = Path.Combine("wwwroot", "images");
                // if there is images with the same name, attach unique name them. So, we cannot get any error.
                uniqueFileName = Guid.NewGuid().ToString() + "_" + myFile.FileName;
                var filePath = Path.Combine(upfolder, uniqueFileName);
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    myFile.CopyTo(fileStream);
                    Image myImage = new Image();
                    myImage.Imagepath = filePath.Remove(0, 8);
                    currentUser.Images.Add(myImage);
                }

            }

            db.SaveChanges();

            // get page number from URL query string
            var page = HttpContext.Request.Query["p"];
            return RedirectToPage(new { p = page, s = 6 });
        }


        // share comments
        public IActionResult OnPostComment(int id, int commentId)
        {
            var strUserId = User.Claims.FirstOrDefault(x => x.Type == ClaimTypes.NameIdentifier)?.Value;
            int userId = int.Parse(strUserId);
            InitiliazeProperties(userId, db);

            // get comments per each image
            if (newText[commentId] != null)
            {
                Comment myComment = new Comment();
                myComment.Text = newText[commentId];
                myComment.ImageId = id;
                myComment.UserId = currentUser.Id;
                db.Comments.Add(myComment);
                db.SaveChanges();

                return RedirectToPage(new { p = staticP, s = 6 });
            }

            else
            {
                return RedirectToPage(new { p = staticP, s = 6 });
            }
        }


    }
}
