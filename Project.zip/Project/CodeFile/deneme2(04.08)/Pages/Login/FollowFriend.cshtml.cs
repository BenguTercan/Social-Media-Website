using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RazorPages.Models;
using RazorPages.Services;


namespace deneme2_04._08_.Pages.Login
{
    public class FollowFriendModel : PageModel
    {

        private readonly AppDbContext db;

        [BindProperty]
        public User currentUser { get; set; }

        [BindProperty]
        public User friendUser { get; set; }

        [BindProperty]
        public FollowedUser followedUser { get; set; }

        [BindProperty]
        public FollowRequest newRequest { get; set; }

        [BindProperty]
        public IEnumerable<FollowRequest> currentRequests { get; set; }

        [BindProperty]
        public IEnumerable<User> AllUsers { get; set; }

        [BindProperty]
        public string SearchTerm { get; set; }



        public FollowFriendModel(AppDbContext _db)
        {
            db = _db;
        }


        private void InitiliazeProperties(int id, AppDbContext db)
        {
            currentUser = db.Users.Include(x => x.FollowedRequests).Include(x => x.FollowedUsers).FirstOrDefault(x => x.Id == id);

            // requests that coming current user
            currentRequests = db.FollowRequests.Include(x => x.User).Where(x => x.ToUserId == currentUser.Id).ToList();

        }


        public void OnGet()
        {
            var strUserId = User.Claims.FirstOrDefault(x => x.Type == ClaimTypes.NameIdentifier)?.Value;
            int userId = int.Parse(strUserId);
            InitiliazeProperties(userId, db);

            // "People" list includes all users except current user
            AllUsers = db.Users.Where(x => x.Id != currentUser.Id).ToList();

        }


        public void OnPost()
        {

        }


        public IActionResult OnPostFollow(int id)
        {
            var strUserId = User.Claims.FirstOrDefault(x => x.Type == ClaimTypes.NameIdentifier)?.Value;
            int userId = int.Parse(strUserId);
            InitiliazeProperties(userId, db);

            friendUser = db.Users.FirstOrDefault(x => x.Id == id);

            // get followment request and create it on FollowRequests table
            newRequest = new FollowRequest()
            {
                UserId = currentUser.Id,
                ToUserId = friendUser.Id
            };

            currentUser.FollowedRequests.Add(newRequest);
            db.SaveChanges();

            return RedirectToPage();
        }


        public IActionResult OnPostUnfollow(int id)
        {
            var strUserId = User.Claims.FirstOrDefault(x => x.Type == ClaimTypes.NameIdentifier)?.Value;
            int userId = int.Parse(strUserId);
            InitiliazeProperties(userId, db);

            friendUser = db.Users.FirstOrDefault(x => x.Id == id);

            // unfollow user
            var deletedFollow = currentUser.FollowedUsers.FirstOrDefault(x => x.FollowedId == id);
            db.Remove(deletedFollow);
            db.SaveChanges();

            return RedirectToPage();
        }


        public IActionResult OnPostAcceptfriend(int id, int requestId)
        {
            var strUserId = User.Claims.FirstOrDefault(x => x.Type == ClaimTypes.NameIdentifier)?.Value;
            int userId = int.Parse(strUserId);
            InitiliazeProperties(userId, db);

            friendUser = db.Users.Include(x => x.FollowedUsers).FirstOrDefault(x => x.Id == id);

            // accept friend request and add the followment relation from friend user to current user
            var followedUser = new FollowedUser() 
            { 
                UserId = friendUser.Id,
                FollowedId = currentUser.Id
            };
            friendUser.FollowedUsers.Add(followedUser);

            // delete request relation from FollowRequests table
            var deletedRequest = db.FollowRequests.Find(requestId);
            db.Remove(deletedRequest);
            db.SaveChanges();

            return RedirectToPage();
        }


        public IActionResult OnPostRejectfriend(int requestId)
        {
            var strUserId = User.Claims.FirstOrDefault(x => x.Type == ClaimTypes.NameIdentifier)?.Value;
            int userId = int.Parse(strUserId);
            InitiliazeProperties(userId, db);

            // reject friend request and delete request relation from FollowRequests table
            var deletedRequest = db.FollowRequests.Find(requestId);
            db.Remove(deletedRequest);
            db.SaveChanges();

            return RedirectToPage();
        }


        public IActionResult OnPostSearch(string SearchTerm)
        {
            var strUserId = User.Claims.FirstOrDefault(x => x.Type == ClaimTypes.NameIdentifier)?.Value;
            int userId = int.Parse(strUserId);
            InitiliazeProperties(userId, db);

            // serach for person name, surname or email address
            if (!string.IsNullOrEmpty(SearchTerm))
            {
                AllUsers = db.Users.Where(x => x.Id != currentUser.Id &&
                                             (x.Name.Contains(SearchTerm) ||
                                               x.Surname.Contains(SearchTerm) ||
                                               x.Email.Contains(SearchTerm)
                                             )
                                          );
            }

            else
                AllUsers = db.Users.Where(x => x.Id != currentUser.Id).ToList();

            return Page();
        }


    }
}
