﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RazorPages.Models;
using RazorPages.Services;

namespace deneme2_04._08_.Pages.Login
{
    public class EditProfileModel : PageModel
    {
        private AppDbContext db;

        [BindProperty]
        public User currentUser { get; set; }

        public EditProfileModel(AppDbContext _db)
        {
            db = _db;
        }


        public void OnGet()
        {
            // get current user
            var strUserId = User.Claims.FirstOrDefault(x => x.Type == ClaimTypes.NameIdentifier)?.Value;
            // convert coming string userId to Integer
            int userId = int.Parse(strUserId);
            currentUser = db.Users.FirstOrDefault(x => x.Id == userId);

        }

        public IActionResult OnPost(string email)
        {
            // to not getting null error for mail
            currentUser.Email = email;

            // user must fill all forms
            if (currentUser.Name != null && currentUser.Surname != null && currentUser.Password != null)
            {
                // password encryption
                currentUser.Password = BCrypt.Net.BCrypt.HashPassword(currentUser.Password);
                db.Entry(currentUser).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToPage("/Login/HomePage");
            }

            return Page();
        }
    }
}
