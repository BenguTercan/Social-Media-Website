﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using RazorPages.Models;
using RazorPages.Services;

namespace deneme2_04._08_.Pages.Login
{
    public class UserProfileModel : PageModel
    {
        private AppDbContext db;

        [BindProperty]
        public User currentUser { get; set; }

        [BindProperty]
        public IEnumerable<FollowedUser> Followers { get; set; }
        [BindProperty]
        public IEnumerable<User> AllUsers { get; set; }

        [BindProperty]
        public IFormFile myFile { get; set; }

        public UserProfileModel(AppDbContext _db)
        {
            db = _db;
        }


        public void OnGet()
        {
            // get Id of currentUser from "claims" variable of Cookie Authentication Scheme to "HomePage" Razor Page
            var strUserId = User.Claims.FirstOrDefault(x => x.Type == ClaimTypes.NameIdentifier)?.Value;

            // convert coming string userId to Integer
            int userId = int.Parse(strUserId);

            /*  To retrieve user's related images we have to use the Include Method. 
                Then join the user table and image table with User.Id and Image.UserId   */
            currentUser = db.Users.Include(x => x.Images).Include(x => x.FollowedUsers).FirstOrDefault(x => x.Id == userId);
            Followers = db.FollowedUsers.Include(x => x.User).Where(x => x.FollowedId == currentUser.Id).ToList();
            AllUsers = db.Users.ToList();
        }

        public void Onpost()
        {

        }

        public IActionResult OnGetDelete(int id, string path)
        {
            var strUserId = User.Claims.FirstOrDefault(x => x.Type == ClaimTypes.NameIdentifier)?.Value;
            int userId = int.Parse(strUserId);
            currentUser = db.Users.Include(x => x.Images).FirstOrDefault(x => x.Id == userId);


            // delete image from database using its "id"
            var deletedImage = db.Images.Find(id);
            db.Remove(deletedImage);
            db.SaveChanges();

            // delete image from wwwroot/images folder using its "path"
            path = Path.Combine("wwwroot", path);
            FileInfo fi = new FileInfo(path);
            if (fi != null)
            {
                System.IO.File.Delete(path);
                fi.Delete();
            }

            return RedirectToPage();
        }

    }
}
